---
name: Ask Question
about: Ask a Pyrogram related question
title: For Q&A purposes, please read this template body
labels: "question"
---

<!-- WARNING: Ignoring this template could lead to the issue being closed as incomplete -->

# Important
This place is for issues about Pyrogram, it's **not a forum**.

If you'd like to post a question, please move to https://stackoverflow.com or join the Telegram community at https://t.me/pyrogram. Useful information on how to ask good questions can be found here: https://stackoverflow.com/help/how-to-ask.

Thanks.
