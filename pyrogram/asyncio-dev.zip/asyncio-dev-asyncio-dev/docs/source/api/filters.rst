Update Filters
==============

Details
-------

.. autoclass:: pyrogram.Filters
    :members:
