# Pyrogram Docs

- Install requirements.
- Install `pandoc` and `latexmk`.
- HTML: `make html`
- PDF: `make latexpdf`

TODO: Explain better